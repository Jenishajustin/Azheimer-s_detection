from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import tensorflow as tf
import cv2
import numpy as np
import matplotlib.pyplot as plt
import tensorflow
# Create your views here.

class_num=np.sort(['Alzheimer_s disease','Cognitively normal','Early mild cognitive impairment','Late mild cognitive impairment'])
details = {
    'Alzheimer_s disease': {
        'Overview': 'Alzheimer\'s disease is a progressive neurodegenerative disorder that affects memory, thinking skills, and behavior.',
        'Symptoms': [
            'Memory loss that disrupts daily life',
            'Difficulty in planning or solving problems',
            'Confusion with time or place',
            'Changes in personality or mood',
            'Withdrawal from work or social activities'
        ],
        'Management': [
            'Medication to manage symptoms (e.g., cholinesterase inhibitors, memantine)',
            'Supportive care and therapy (e.g., cognitive stimulation, occupational therapy)',
            'Healthy lifestyle changes (e.g., regular exercise, balanced diet)',
            'Caregiver support and education',
            'Clinical trials for potential treatments'
        ]
    },
    'Cognitively normal': {
        'Overview': 'Cognitively normal individuals have typical cognitive function for their age group with no significant impairment.',
        'Symptoms': [],
        'Management': []
    },
    'Early mild cognitive impairment': {
        'Overview': 'Early Mild Cognitive Impairment (EMCI) is a stage of cognitive decline greater than normal aging but not severe enough to interfere significantly with daily life.',
        'Symptoms': [
            'Forgetting recent events or conversations',
            'Difficulty with complex tasks',
            'Mild word-finding problems',
            'Trouble remembering new names',
            'Frequently losing items'
        ],
        'Management': [
            'Cognitive and memory exercises (e.g., puzzles, memory games)',
            'Regular physical activity (e.g., walking, swimming)',
            'Healthy diet (e.g., Mediterranean diet)',
            'Social engagement (e.g., group activities, volunteering)',
            'Monitoring cardiovascular health (e.g., managing blood pressure, cholesterol)'
        ]
    },
    'Late mild cognitive impairment': {
        'Overview': 'Late Mild Cognitive Impairment (LMCI) is a more advanced stage of cognitive decline than EMCI, with noticeable memory and cognitive issues affecting daily activities.',
        'Symptoms': [
            'More pronounced memory loss',
            'Difficulty managing finances or medications',
            'Trouble following instructions',
            'Noticeable changes in planning and organization',
            'Increased confusion'
        ],
        'Management': [
            'Cognitive rehabilitation programs',
            'Physical exercise (e.g., strength training, flexibility exercises)',
            'Nutritional support (e.g., supplements, meal planning)',
            'Social and mental activities (e.g., cognitive behavioral therapy, support groups)',
            'Medication management (e.g., for symptoms like anxiety or sleep disturbances)'
        ]
    }
}

def home(request):
    return render(request,'alzaware/home.html')

def early_detection(request):
    if request.method == 'POST':
        # Get the uploaded file
        image = request.FILES['file']
        # Save the file using FileSystemStorage
        fs = FileSystemStorage()
        # Delete the previous file if exists
        try:
            fs.delete('temp.png')
        except:
            pass
        filename = fs.save('temp.png', image)
        file_url = fs.url(filename)
        print(f"File saved at: {file_url}")

        # Load the model
        model = load_model()
        print("Model loaded successfully")
        # Classify the image
        predicted_class, confidence = classify_image(f'media/{filename}', model)
        print(f"Predicted class: {predicted_class}")
        print(f"Confidence: {confidence}")
        # Visualize the result
        visualize_prediction(f'media/{filename}', predicted_class, confidence)
        print("Result visualized successfully")

        # Pass results to the template
        context = {
            'predicted_class': predicted_class,
            'confidence': confidence,
            'file_url': file_url,
            'overview': details[predicted_class]['Overview'],
            'symptoms': details[predicted_class]['Symptoms'],
            'management': details[predicted_class]['Management']
        }
        return render(request, 'alzaware/results.html', context)
    
    return render(request, 'alzaware/early_detection.html')

def results(request):
    return render(request,'alzaware/results.html')

def load_model():
        # Load the model without the optimizer
    model = tensorflow.keras.models.load_model('alzaware\CNN_model.h5', compile=False)
    # Compile the model with a compatible optimizer
    model.compile(optimizer ='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model
   

# Function to preprocess the image
def preprocess_image(image_path, target_size=(32, 32)):
    # Load the image
    img = cv2.imread(image_path)
    # Resize the image
    img = cv2.resize(img, target_size)
    # Convert the image to RGB
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # Normalize the image
    img = img / 255.0
    # Expand dimensions to match the input shape of the model
    img = np.expand_dims(img, axis=0)
    return img

# Function to predict the class of an image
def classify_image(image_path, model):
    # Preprocess the image
    img = preprocess_image(image_path)
    # Make prediction
    prediction = model.predict(img)
    # Get the predicted class index
    predicted_class_index = np.argmax(prediction, axis=1)[0]
    # Get the predicted class label
    predicted_class_label = class_num[predicted_class_index]
    # Get the confidence of the prediction
    confidence = prediction[0][predicted_class_index]
    return predicted_class_label, confidence

# Visualize the result
def visualize_prediction(image_path, predicted_class, confidence):
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    font_scale = 0.5
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_thickness = 1
    text = f"{predicted_class}, - {confidence:.2f}"
    text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
    text_x = 10
    text_y = img.shape[0] - 10
    text_box_x = text_x
    text_box_y = text_y - text_size[1] - 10
    text_box_width = img.shape[1]
    text_box_height = text_size[1] + 10
    cv2.rectangle(img, (text_box_x, text_box_y), (text_box_x + text_box_width, text_box_y + text_box_height), (255, 255, 255), -1)
    cv2.putText(img, text, (text_x, text_y), font, font_scale, (0, 0, 0), font_thickness)
    plt.imsave('media/result.png', img)

